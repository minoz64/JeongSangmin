#include "Weapon.h"



Weapon::Weapon()
{
}


Weapon::~Weapon()
{

}


void Weapon::SaveWeaponInfo(ifstream& Load)
{	
	Load >> m_WeaponInfo.WeaponType;
	Load >> m_WeaponInfo.WeaponName;
	Load >> m_WeaponInfo.Damege;
	Load >> m_WeaponInfo.Cost;
}

void Weapon::WeaponListTxt(int x, int y)
{
	YELLOW
		m_MapDraw.DrawMidText("���� : " + to_string(m_WeaponInfo.Cost) + " ���� Ÿ�� : " + m_WeaponInfo.WeaponType, x, y + 1);
	m_MapDraw.DrawMidText("���� �̸� : " + m_WeaponInfo.WeaponName + " ���ݷ� : " + to_string(m_WeaponInfo.Damege), x, y + 2);
	ORIGINAL
}

Dagger::Dagger()
{

}

Dagger::~Dagger()
{

}
Gun::Gun()
{

}
Gun::~Gun()
{

}

Bow::Bow()
{

}

Bow::~Bow()
{

}

Wand::Wand()
{

}

Wand::~Wand()
{

}

Sword::Sword()
{

}
Sword::~Sword()
{

}
Hammer::Hammer()
{

}
Hammer::~Hammer()
{

}

void Dagger::Attack()
{
	cout << "Attack";
}

void Bow::Attack()
{
	cout << "Attack";
}
void Wand::Attack()
{
	cout << "Attack";
}

void Gun::Attack()
{
	cout << "Attack";
}

void Sword::Attack()
{
	cout << "Attack";
}

void Hammer::Attack()
{
	cout << "Attack";
}