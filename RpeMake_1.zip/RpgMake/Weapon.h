#pragma once
#include "MapDraw.h"

struct WeaponInfo
{
	int Cost, Damege;
	string WeaponName, WeaponType;
};


class Weapon//���⿡ ���������� �־���� �� - ������,����,�̸�,���� Ÿ��
{
protected:
	MapDraw m_MapDraw;
	WeaponInfo m_WeaponInfo;
public:
	Weapon();
	~Weapon();
	virtual void Attack()=0;
	void SaveWeaponInfo(
		ifstream& Load);
	void WeaponListTxt(int x, int y);
	inline string ReturnWeaponName()
	{
		return m_WeaponInfo.WeaponType;
	}
	inline WeaponInfo ReturnWeaponInfo()
	{
		return m_WeaponInfo;
	}
};

class Dagger : public Weapon
{
public:
	Dagger();
	~Dagger();
	void Attack();
};



class Gun : public Weapon
{
public:
	Gun();
	~Gun();
	void Attack();
};

class Sword : public Weapon
{
public:
	Sword();
	~Sword();
	void Attack();
};

class Wand : public Weapon
{
public:
	Wand();
	~Wand();
	void Attack();
};

class Bow :public Weapon
{
public:
	Bow();
	~Bow();
	void Attack();
};

class Hammer : public Weapon
{
public:
	Hammer();
	~Hammer();
	void Attack();
};




