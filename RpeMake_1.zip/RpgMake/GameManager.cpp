#include "GameManager.h"



GameManager::GameManager()
{
	Player = NULL;
	Monster=NULL;
	m_iMonsterCount = 0;
}


GameManager::~GameManager()
{
}

void GameManager::Init()
{
	m_bGameEnd = true,m_bSave = false, m_bLoad = false;
	if (Player)
		delete Player;
	if (Monster)
		delete[] Monster;
}

void GameManager::Menu_Text()
{
	RED
	m_DrawMap.DrawMidText("�١� DonGeonRPG �ڡ�", WIDTH, HEIGHT*.4);
	m_DrawMap.DrawMidText("New Game", WIDTH, HEIGHT*.5);
	m_DrawMap.DrawMidText("Load Game", WIDTH, HEIGHT*.6);
	m_DrawMap.DrawMidText("Game Exit", WIDTH, HEIGHT*.7);
}

void GameManager::DongeonMenu_Text()
{
	RED
	m_DrawMap.DrawMidText("�١� Menu �ڡ�", WIDTH, HEIGHT*.2);
	m_DrawMap.DrawMidText("Dongeon", WIDTH, HEIGHT*.3);
	m_DrawMap.DrawMidText("Player Info", WIDTH, HEIGHT*.4);
	m_DrawMap.DrawMidText("Monster Info", WIDTH, HEIGHT*.5);
	m_DrawMap.DrawMidText("Weapon Shop", WIDTH, HEIGHT*.6);
	m_DrawMap.DrawMidText("Save", WIDTH, HEIGHT*.7);
	m_DrawMap.DrawMidText("Exit", WIDTH, HEIGHT*.8);
}

void GameManager::Menu()
{
	MenuSelectNum Select;
	ifstream Load;
	UnitTYPE type;
	system("mode con: lines=35 cols=60");
	Init();
	while (1)
	{
		m_DrawMap.Outline_Box();
		Menu_Text();
		Select =(MenuSelectNum)m_DrawMap.MenuSelectCursor(3, 3, (WIDTH / 3) + 1, HEIGHT*.5);
		switch (Select)
		{
		case NEW_GAME:
			m_DrawMap.Outline_Box();
			YELLOW
			Player = new Unit;
			Load.open("DefaultPlayer.txt");
			Player->Init(Load,PLAYER);
			Load.close();
			Load.open("DefaultMonster.txt");
			Load >> m_iMonsterCount;
			Monster = new Unit[m_iMonsterCount];
			for (int i = 0; i < m_iMonsterCount; i++)
			{
				Monster[i].Init(Load,MONSTER);
			}
			Load.close();
			Dongeon_Menu();
			break;
		case LOAD_GAME:
			Load.open("DefaultMonster.txt");
			Load >> m_iMonsterCount;
			Load.close();
			Player = new Unit;
			Monster = new Unit[m_iMonsterCount];
			SaveLoadMenu(m_bSave = false,m_bLoad = true);
			break;
		case GAME_EXIT:
			exit(1);
			break;
		default:
			break;
		}
	}
}

void GameManager::DongeonFightMenu()
{
	m_DrawMap.Outline_Box();
	RED
	m_DrawMap.DrawMidText("===== ���� �Ա�=====", WIDTH, HEIGHT*0.2);
	for (int i = 1; i <= m_iMonsterCount; i++)
	{
		m_DrawMap.gotoxy(WIDTH-7,(HEIGHT*(0.1*i)+7));
		cout << i << "�� ���� : " << "["<<Monster[i-1].UnitInfo().m_strName<<"]"<<endl;
	}
	int Select = m_DrawMap.MenuSelectCursor(6, 3, (WIDTH / 3), HEIGHT*0.35);
	Fight(Player, &Monster[Select-1]);
}

void GameManager::Dongeon_Menu()
{
	DongeonMenuSelectNum Select;
	char ch;
	m_bGameEnd = true;
	while (m_bGameEnd)
	{
		m_DrawMap.Outline_Box();
		DongeonMenu_Text();
		Select = (DongeonMenuSelectNum)m_DrawMap.MenuSelectCursor(6, 3, (WIDTH / 3) + 1, HEIGHT*0.3);
		switch (Select)
		{
		case DONGEON:
			DongeonFightMenu();
			break;
		case PLAYER_INFO:
			m_DrawMap.Outline_Box();
			Player->ShowInfo(WIDTH/2,HEIGHT*0.4);
			ch = getch();
			break;
		case MONSTER_INFO:
			m_DrawMap.Outline_Box();
			for (int i = 0; i < m_iMonsterCount; i++)
			{
				Monster[i].ShowInfo(WIDTH/2,(HEIGHT*0.1)+i*4);
			}
			ch = getch();
			break;
		case WEAPON_SHOP:
			m_Store.WeaponShop(Player);
			break;
		case SAVE:
			SaveLoadMenu(m_bSave=true,m_bLoad=false);
			break;
		case EXIT:
			m_bGameEnd = false;
			break;
		}
	}
}

bool GameManager::WinLose(RSP PlayerRSP, RSP MonsterRSP,Unit* Monster)
{
	if (PlayerRSP == ROCK && MonsterRSP == ROCK)
	{
		m_DrawMap.DrawMidText("����", WIDTH, HEIGHT*0.4);
		RED
		m_DrawMap.DrawMidText("DRAW", WIDTH, HEIGHT*0.45);
		m_DrawMap.DrawMidText("DRAW", WIDTH, HEIGHT*0.6);
		ORIGINAL
		m_DrawMap.DrawMidText("����", WIDTH, HEIGHT*0.65);
		return true;
	}

	else if (PlayerRSP == ROCK && MonsterRSP == SCISSOR)
	{
		m_DrawMap.DrawMidText("����", WIDTH, HEIGHT*0.4);
		RED
			m_DrawMap.DrawMidText("WIN", WIDTH, HEIGHT*0.45);
		m_DrawMap.DrawMidText("LOSE", WIDTH, HEIGHT*0.6);
		ORIGINAL
			m_DrawMap.DrawMidText("����", WIDTH, HEIGHT*0.65);

		m_bFightEnd = Player->Attack(Player, Monster, Player);
	}

	else if (PlayerRSP == ROCK && MonsterRSP == PAPER)
	{
		m_DrawMap.DrawMidText("����", WIDTH, HEIGHT*0.4);
		RED
			m_DrawMap.DrawMidText("LOSE", WIDTH, HEIGHT*0.45);
		m_DrawMap.DrawMidText("WIN", WIDTH, HEIGHT*0.6);
		ORIGINAL
			m_DrawMap.DrawMidText("��", WIDTH, HEIGHT*0.65);

		m_bFightEnd=Monster->Attack(Monster, Player, Player);
	}

	else if (PlayerRSP == SCISSOR && MonsterRSP == ROCK)
	{
		m_DrawMap.DrawMidText("����", WIDTH, HEIGHT*0.4);
		RED
			m_DrawMap.DrawMidText("LOSE", WIDTH, HEIGHT*0.45);
		m_DrawMap.DrawMidText("WIN", WIDTH, HEIGHT*0.6);
		ORIGINAL
			m_DrawMap.DrawMidText("����", WIDTH, HEIGHT*0.65);

		m_bFightEnd=Monster->Attack(Monster, Player, Player);
	}

	else if (PlayerRSP == SCISSOR && MonsterRSP == SCISSOR)
	{
		m_DrawMap.DrawMidText("����", WIDTH, HEIGHT*0.4);
		RED
			m_DrawMap.DrawMidText("DRAW", WIDTH, HEIGHT*0.45);
		m_DrawMap.DrawMidText("DRAW", WIDTH, HEIGHT*0.6);
		ORIGINAL
			m_DrawMap.DrawMidText("����", WIDTH, HEIGHT*0.65);
		return true;
	}

	else if (PlayerRSP == SCISSOR && MonsterRSP == PAPER)
	{
		m_DrawMap.DrawMidText("����", WIDTH, HEIGHT*0.4);
		RED
			m_DrawMap.DrawMidText("WIN", WIDTH, HEIGHT*0.45);
		m_DrawMap.DrawMidText("LOSE", WIDTH, HEIGHT*0.6);
		ORIGINAL
			m_DrawMap.DrawMidText("��", WIDTH, HEIGHT*0.65);

		m_bFightEnd=Player->Attack(Player, Monster, Player);
	}

	else if (PlayerRSP == PAPER && MonsterRSP == ROCK)
	{
		m_DrawMap.DrawMidText("��", WIDTH, HEIGHT*0.4);
		RED
			m_DrawMap.DrawMidText("WIN", WIDTH, HEIGHT*0.45);
		m_DrawMap.DrawMidText("LOSE", WIDTH, HEIGHT*0.6);
		ORIGINAL
			m_DrawMap.DrawMidText("����", WIDTH, HEIGHT*0.65);

		m_bFightEnd=Player->Attack(Player, Monster, Player);
	}

	else if (PlayerRSP == PAPER && MonsterRSP == SCISSOR)
	{
		m_DrawMap.DrawMidText("��", WIDTH, HEIGHT*0.4);
		RED
			m_DrawMap.DrawMidText("LOSE", WIDTH, HEIGHT*0.45);
		m_DrawMap.DrawMidText("WIN", WIDTH, HEIGHT*0.6);
		ORIGINAL
			m_DrawMap.DrawMidText("����", WIDTH, HEIGHT*0.65);

		m_bFightEnd=Monster->Attack(Monster, Player, Player);
	}

	else if (PlayerRSP == PAPER && MonsterRSP == PAPER)
	{
		m_DrawMap.DrawMidText("��", WIDTH, HEIGHT*0.4);
		RED
			m_DrawMap.DrawMidText("DRAW", WIDTH, HEIGHT*0.45);
		m_DrawMap.DrawMidText("DRAW", WIDTH, HEIGHT*0.6);
		ORIGINAL
			m_DrawMap.DrawMidText("��", WIDTH, HEIGHT*0.65);
		return true;
	}
}





void GameManager::Fight(Unit* Player, Unit* Monster)
{
	char ch;
	int MonsterRSP;
	m_DrawMap.Outline_Box();
	m_bFightEnd = true;
	while (m_bFightEnd)//false�� ��
	{
		BLUE
			Player->ShowInfo(WIDTH / 2, (HEIGHT*0.15));
		m_DrawMap.DrawMidText("���� :1    ���� : 2    �� :3", WIDTH, HEIGHT*0.3);
		RED
			m_DrawMap.DrawMidText("---------------------------vs---------------------------", WIDTH, HEIGHT*0.5);
		ORIGINAL
			Monster->ShowInfo(WIDTH / 2, (HEIGHT*0.8));
		MonsterRSP = (rand() % 3) + 1;
		ch = getch();
		m_DrawMap.Outline_Box();
		switch (ch-48)
		{
		case SCISSOR:
			m_bFightEnd=WinLose(SCISSOR,(RSP)MonsterRSP,Monster);
			break;
		case ROCK:
			m_bFightEnd=WinLose(ROCK, (RSP)MonsterRSP, Monster);
			break;
		case PAPER:
			m_bFightEnd=WinLose(PAPER, (RSP)MonsterRSP, Monster);
			break;
		}
		if (Player->ReturnPlayerLife() <= 0)
		{
			m_DrawMap.Outline_Box();
			m_DrawMap.DrawMidText("Game Over", WIDTH, HEIGHT*0.5);
			for (int i = 0; i < m_iMonsterCount; i++)
				Monster[i].HealReset();
			ch = getch();
			Menu();
		}
	}
}

void GameManager::FileCheck()//������ �ִ��� ������ Ȯ��
{
	ifstream PlayerFile;
	string strFile ;
	for (int i = 1; i < 11; i++)
	{
		strFile = "SavePlayer" + to_string(i) + ".txt";
		PlayerFile.open(strFile);
		if (PlayerFile.is_open() == true)
		{
			m_strFile[i] = "0";
		}
		else
			m_strFile[i] = "X";
		PlayerFile.close();
	}
}
void GameManager::FileTxt(int x, int y,int count)//���� �ؽ�Ʈ �����ֱ�
{
	count += 1;
	m_DrawMap.gotoxy(x, y + count);
	FileCheck();
	if (count == SAVEFILEMAXCOUNT)
	{
		cout << count<<".���ư���" << endl;
	}
	else
	{
		cout << count << "�� ���� : " << "<���� ���� :" <<m_strFile[count]<<">"<< endl;
	}
}

void GameManager::Save(int num)//���� ���� �����ϱ�
{
	ofstream Save;
	string FileName;
	FileName = "SavePlayer" + to_string(num) + ".txt";
	Save.open(FileName);
	Player->InfoSave(num,Save);
	Save.close();
	FileName = "SaveMonster" + to_string(num) + ".txt";
	Save.open(FileName);
	Save << m_iMonsterCount<<"\n";
	for(int i=0;i<m_iMonsterCount;i++)
		Monster[i].InfoSave(num,Save);
	Save.close();
}

void GameManager::Load(int num)
{
	ifstream Load;
	string FileName;
	FileName = "SavePlayer" + to_string(num) + ".txt";
	Load.open(FileName);
	if (Load.is_open() == true)
	{
		Player->InfoLoad(Load);
	}
	Load.close();
	FileName = "SaveMonster" + to_string(num) + ".txt";
	Load.open(FileName);
	Load >> m_iMonsterCount;

	for (int i = 0; i < m_iMonsterCount; i++)
	{
		Monster[i].InfoLoad(Load);
	}
	Load.close();
	Dongeon_Menu();
}

void GameManager::SaveLoadMenu(bool save,bool load)
{
	bool b_Menureturn=true;
	while (b_Menureturn)
	{
		m_DrawMap.Outline_Box();
		m_DrawMap.gotoxy(WIDTH / 2, HEIGHT*.2);
		GREEN;
		for (int i = 0; i < SAVEFILEMAXCOUNT; i++)
		{
			FileTxt(WIDTH / 2, (HEIGHT*.1) + i, i);
		}
		int Select = m_DrawMap.MenuSelectCursor(11, 2, (WIDTH*0.2), HEIGHT*0.15);
		if (m_bSave == true && m_bLoad == false)
		{
			if (Select == 11)
				b_Menureturn = false;
			else
				Save(Select);
		}
		else if (m_bSave == false && m_bLoad == true)
		{
			if (Select == 11)
				b_Menureturn = false;
			else
				Load(Select);
		}
	}
}