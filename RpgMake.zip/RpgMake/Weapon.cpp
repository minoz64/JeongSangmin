#include "Weapon.h"



Weapon::Weapon()
{
}


Weapon::~Weapon()
{

}
void Weapon::BuyItem(Unit* Player)
{
	if (Player->UnitInfo().m_iGOLD > m_WeaponInfo.Cost)
	{
		
	}
}

void Weapon::SaveWeaponInfo(ifstream& Load)
{
	Load >> m_WeaponInfo.WeaponType;
	Load >> m_WeaponInfo.WeaponName;
	Load >> m_WeaponInfo.Damege;
	Load >> m_WeaponInfo.Cost;
}

void Weapon::WeaponListTxt(int x, int y)
{
	YELLOW
	m_MapDraw.DrawMidText("���� : " + to_string(m_WeaponInfo.Cost) + " ���� Ÿ�� : " + m_WeaponInfo.WeaponType, x, y + 1);
	m_MapDraw.DrawMidText("���� �̸� : " + m_WeaponInfo.WeaponName + " ���ݷ� : " + to_string(m_WeaponInfo.Damege), x, y + 2);
	ORIGINAL
}