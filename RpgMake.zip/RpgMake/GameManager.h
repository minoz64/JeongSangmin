#pragma once
#include "Weapon.h"
#define SAVEFILEMAXCOUNT 11

enum WEAPON
{
	DAGGER = 1,
	GUN,
	SWORD,
	WAND,
	BOW,
	HAMMER
};
enum WDL
{
	WIN = 0,
	DRAW,
	LOSE
};
enum RSP
{
	SCISSOR=1,
	ROCK,
	PAPER
};

enum MenuSelectNum
{
	NEW_GAME =1,
	LOAD_GAME,
	GAME_EXIT
};

enum DongeonMenuSelectNum
{
	DONGEON = 1,
	PLAYER_INFO,
	MONSTER_INFO,
	WEAPON_SHOP,
	SAVE,
	EXIT
};

class GameManager
{
private:
	MapDraw m_DrawMap;
	Unit* Player;
	Unit* Monster;
	Weapon* Weapons;
	bool m_bGameEnd,m_bSave,m_bLoad,m_bFightEnd;
	int m_iMonsterCount,m_iWeaponCount;
	string m_strFile[SAVEFILEMAXCOUNT];
public:
	GameManager();
	~GameManager();
	void Init();
	void Menu();
	void Menu_Text();
	void DongeonMenu_Text();
	void Dongeon_Menu();
	void DongeonFightMenu();
	void SaveLoadMenu(bool save,bool load);
	void FileTxt(int x, int y,int count);
	void Save(int num);
	void Load(int num);
	void FileCheck();
	void Fight(Unit* Player, Unit* Monster);
	bool WinLose(RSP PlayerRSP,RSP MonsterRSP,Unit* Monster);
	void WeaponShopTxt();
	void WeaponShop();
	void WeaponList(WEAPON Type);
	void LoadWeaponList(int MaxWeaponCount);
	void WeaponListTxt(WEAPON Type);
	int MaxWepaonCount(WEAPON Type);
	string WeaponGetName(WEAPON Type);
};

