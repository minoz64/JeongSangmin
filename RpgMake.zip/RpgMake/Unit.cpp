#include "Unit.h"



Unit::Unit()
{
}


Unit::~Unit()
{
}

void Unit::Init(ifstream& Load, UnitTYPE Type)
{
	if (Type == PLAYER) //���� �ϳ� �� �ɾ���ҵ� ó������ �ƴ��� Ȯ��
	{
		m_DrawMap.DrawMidText("Player �̸� �Է� : ", WIDTH, HEIGHT*0.5);
		cin >> Info.m_strName;
	}
	else
	{
		Load >> Info.m_strName;
	}
	Load >> Info.m_iPower;
	Load >> Info.m_iHealth;
	Load >> Info.m_iMAXEXP;
	Load >> Info.m_iGetEXP;
	Load >> Info.m_iLevel;
	Load >> Info.m_iGOLD;
	Info.m_CurHealth = Info.m_iHealth;
	Info.m_iCurEXP = 0;
}

void Unit::InfoLoad(ifstream& Load)
{
	Load >> Info.m_strName;
	Load >> Info.m_iPower;
	Load >> Info.m_iHealth;
	Load >> Info.m_iMAXEXP;
	Load >> Info.m_iGetEXP;
	Load >> Info.m_iLevel;
	Load >> Info.m_iGOLD;
	Load >> Info.m_iCurEXP;
	Load >> Info.m_CurHealth;
}

void Unit::InfoSave(int num,ofstream& Save)
{
	Save << Info.m_strName<<" ";
	Save << Info.m_iPower<<" ";
	Save << Info.m_iHealth <<" ";
	Save << Info.m_iMAXEXP<<" ";
	Save << Info.m_iGetEXP << " ";
	Save << Info.m_iLevel << " ";
	Save << Info.m_iGOLD << " ";
	Save << Info.m_iCurEXP << " ";
	Save << Info.m_CurHealth<<" "<<endl;
}

void Unit::ShowInfo(int x,int y)
{
	m_DrawMap.gotoxy(x,y);
	cout << "  ======" << Info.m_strName << "(" << Info.m_iLevel << "Lv)======" << endl;
	m_DrawMap.gotoxy(x, y+1);
	cout << "\t���ݷ� = " <<Info.m_iPower <<"\t������ = "<<Info.m_CurHealth<<"/"<<Info.m_iHealth << endl;
	m_DrawMap.gotoxy(x, y+2);
	cout << "\t����ġ :"<<Info.m_iCurEXP <<"/" <<Info.m_iMAXEXP <<"\t GETEXP :"<< Info.m_iGetEXP << endl;
	m_DrawMap.gotoxy(x ,y+3);
	cout << "\tGold :" << Info.m_iGOLD << endl;
}

bool Unit::Attack(Unit* WinUnit,Unit* LoseUnit,Unit* PlayerName)//Unit
{
	int DAM;
	DAM = WinUnit->Info.m_iPower;
	LoseUnit->Info.m_CurHealth -= DAM;
	if (LoseUnit->Info.m_CurHealth <= 0)
	{
		m_DrawMap.Outline_Box();
		LoseUnit->Info.m_CurHealth = 0;
		WinUnit->Info.m_iCurEXP+=LoseUnit->Info.m_iGetEXP;
		
		m_DrawMap.DrawMidText(WinUnit->Info.m_strName + "�¸�", WIDTH, HEIGHT*0.3);
		m_DrawMap.DrawMidText(WinUnit->Info.m_strName + " �� ����ġ "+to_string(LoseUnit->Info.m_iGetEXP)+
			" �� ������ϴ�.", WIDTH, HEIGHT*0.5);
		getch();
		if (WinUnit->Info.m_iCurEXP >= WinUnit->Info.m_iMAXEXP)
		{
			WinUnit->LevelUp();
		}
		LoseUnit->HealReset();
		return false;
	}
	return true;
}

void Unit::HealReset()
{
	Info.m_CurHealth = Info.m_iHealth;
}

void Unit::LevelUp()
{
	int PowerUpgrade,HealthUpgrade;
	PowerUpgrade = ceil(Info.m_iPower*0.2);
	HealthUpgrade = ceil(Info.m_CurHealth*0.3);
	Info.m_iPower += PowerUpgrade;
	Info.m_iHealth += HealthUpgrade;
	Info.m_iLevel++;
	m_DrawMap.Outline_Box();
	m_DrawMap.DrawMidText(Info.m_strName + " Level Up!", WIDTH, HEIGHT*0.3);
	m_DrawMap.DrawMidText("���ݷ� " + to_string(PowerUpgrade) + "����", WIDTH, HEIGHT*0.5);
	m_DrawMap.DrawMidText("������ " + to_string(HealthUpgrade) + "����", WIDTH, HEIGHT*0.7);
	HealReset();
	getch();
}