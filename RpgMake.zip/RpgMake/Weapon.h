#pragma once
#include "Unit.h"

struct WeaponInfo
{
	int Cost, Damege;
	string WeaponName, WeaponType;
};


class Weapon//���⿡ ���������� �־���� �� - ������,����,�̸�,���� Ÿ��
{
protected:
	MapDraw m_MapDraw;
	WeaponInfo m_WeaponInfo;
public:
	Weapon();
	~Weapon();
	virtual void Attack()=0;
	void SaveWeaponInfo(ifstream& Load);
	void BuyItem(Unit* Player);
	void WeaponListTxt(int x, int y);
	inline string ReturnWeaponName()
	{
		return m_WeaponInfo.WeaponType;
	}
	inline WeaponInfo ReturnWeaponInfo()
	{
		return m_WeaponInfo;
	}
};

class Dagger : public Weapon
{
	Dagger();
	~Dagger();
	Dagger(string Name, string Type, int cost, int Dam);
	void Attack();
	//void DaggerInfo(string Name, string Type, int cost, int Dam);
	//�־ȵǴ����𸣰���
};

class Gun : public Weapon
{

};

class Sword : public Weapon
{

};

class Wand : public Weapon
{

};

class Bow :public Weapon
{

};

class Hammer : public Weapon
{

};




