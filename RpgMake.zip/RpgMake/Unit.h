#pragma once
#include "MapDraw.h"
enum UnitTYPE
{
	PLAYER,
	MONSTER
};

struct Unit_Info
{
	string m_strName;
	int m_iPower;
	int m_CurHealth;
	int m_iHealth;
	int m_iLevel;
	int m_iCurEXP;
	int m_iGetEXP;
	int m_iGOLD;
	int m_iMAXEXP;
};

class Unit
{
private:
	MapDraw m_DrawMap;
	ofstream Save;
	ifstream Load;
protected:
	Unit_Info Info;
public:
	Unit();
	~Unit();
	void Init(ifstream& Load, UnitTYPE Type);
	void ShowInfo(int x, int y);
	void InfoSave(int num, ofstream& Save);
	void InfoLoad(ifstream& Load);
	bool Attack(Unit* WinUnit,Unit* LoseUnit, Unit* PlayerName);
	void HealReset();
	void LevelUp();
	inline Unit_Info UnitInfo()
	{
		return Info;
	}
	inline int ReturnPlayerLife()
	{
		return Info.m_CurHealth;
	}
};

