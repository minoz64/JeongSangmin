#pragma once
#include "MapDraw.h"

struct WeaponInfo
{
	int Cost, Damege;
	string WeaponName, WeaponType;
};


class Weapon//���⿡ ���������� �־���� �� - ������,����,�̸�,���� Ÿ��
{
protected:
	MapDraw m_MapDraw;
	WeaponInfo m_WeaponInfo;
	int m_iAddDamege;
public:
	Weapon();
	~Weapon();
	virtual int Attack()=0;
	void SaveWeaponInfo(ifstream& Load);
	void WeaponListTxt(int x, int y);
	inline string ReturnWeaponName()
	{
		return m_WeaponInfo.WeaponType;
	}
	inline WeaponInfo ReturnWeaponInfo()
	{
		return m_WeaponInfo;
	}
	inline int ReturnWeaponDam()
	{
		return m_WeaponInfo.Damege;
	}
	inline int ReturnWeaponcost()
	{
		return m_WeaponInfo.Cost;
	}
};

class Dagger : public Weapon
{
public:
	Dagger();
	Dagger(string Type,string Name,int Damege,int Cost);
	~Dagger();
	int Attack();
};



class Gun : public Weapon
{
public:
	Gun();
	Gun(string Type, string Name, int Damege, int Cost);
	~Gun();
	int Attack();
};

class Sword : public Weapon
{
public:
	Sword();
	Sword(string Type, string Name, int Damege, int Cost);
	~Sword();
	int Attack();
};

class Wand : public Weapon
{
public:
	Wand();
	Wand(string Type, string Name, int Damege, int Cost);
	~Wand();
	int Attack();
};

class Bow :public Weapon
{
public:
	Bow();
	Bow(string Type, string Name, int Damege, int Cost);
	~Bow();
	int Attack();
};

class Hammer : public Weapon
{
public:
	Hammer();
	Hammer(string Type, string Name, int Damege, int Cost);
	~Hammer();
	int Attack();
};




