#include "GameManager.h"

void main()
{
	GameManager GM;
	GM.Menu();
}