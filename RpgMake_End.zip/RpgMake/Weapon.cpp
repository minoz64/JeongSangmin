#include "Weapon.h"



Weapon::Weapon()
{
	srand(time(NULL));
}


Weapon::~Weapon()
{

}

void Weapon::SaveWeaponInfo(ifstream& Load)
{	
	Load >> m_WeaponInfo.WeaponType;
	Load >> m_WeaponInfo.WeaponName;
	Load >> m_WeaponInfo.Damege;
	Load >> m_WeaponInfo.Cost;
}

void Weapon::WeaponListTxt(int x, int y)
{
	YELLOW
	m_MapDraw.DrawMidText("���� : " + to_string(m_WeaponInfo.Cost) + " ���� Ÿ�� : " + m_WeaponInfo.WeaponType, x, y + 1);
	m_MapDraw.DrawMidText("���� �̸� : " + m_WeaponInfo.WeaponName + " ���ݷ� : " + to_string(m_WeaponInfo.Damege), x, y + 2);
	ORIGINAL
}

Dagger::Dagger()
{

}

Dagger::~Dagger()
{

}

Gun::Gun()
{

}
Gun::Gun(string Type, string Name, int Damege, int Cost)
{
	m_WeaponInfo.WeaponType = Type;
	m_WeaponInfo.WeaponName = Name;
	m_WeaponInfo.Damege = Damege;
	m_WeaponInfo.Cost = Cost;
}
Gun::~Gun()
{

}

Bow::Bow(string Type, string Name, int Damege, int Cost)
{
	m_WeaponInfo.WeaponType = Type;
	m_WeaponInfo.WeaponName = Name;
	m_WeaponInfo.Damege = Damege;
	m_WeaponInfo.Cost = Cost;
}

Bow::Bow()
{

}

Bow::~Bow()
{

}

Wand::Wand(string Type, string Name, int Damege, int Cost)
{
	m_WeaponInfo.WeaponType = Type;
	m_WeaponInfo.WeaponName = Name;
	m_WeaponInfo.Damege = Damege;
	m_WeaponInfo.Cost = Cost;
}

Wand::Wand()
{

}

Wand::~Wand()
{

}
Sword::Sword()
{

}

Sword::Sword(string Type, string Name, int Damege, int Cost)
{
	m_WeaponInfo.WeaponType = Type;
	m_WeaponInfo.WeaponName = Name;
	m_WeaponInfo.Damege = Damege;
	m_WeaponInfo.Cost = Cost;
}

Sword::~Sword()
{

}

Hammer::Hammer()
{

}
Hammer::Hammer(string Type, string Name, int Damege, int Cost)
{
	m_WeaponInfo.WeaponType = Type;
	m_WeaponInfo.WeaponName = Name;
	m_WeaponInfo.Damege = Damege;
	m_WeaponInfo.Cost = Cost;
}
Hammer::~Hammer()
{

}
Dagger::Dagger(string Type, string Name, int Damege, int Cost)
{
	m_WeaponInfo.WeaponType = Type;
	m_WeaponInfo.WeaponName = Name;
	m_WeaponInfo.Damege = Damege;
	m_WeaponInfo.Cost = Cost;
}
int Dagger::Attack()
{
	m_iAddDamege = 0;
	if (rand() % 100 <= 100)
	{
		m_iAddDamege = m_WeaponInfo.Damege * 2;
		m_MapDraw.DrawMidText("���� ����! �߰� ���ط� :"+to_string(m_iAddDamege), WIDTH, HEIGHT*0.48);
	}
	return m_WeaponInfo.Damege+ m_iAddDamege;
}

int Bow::Attack()
{
	m_iAddDamege = 0;
	if (rand() % 100 <= 25)
	{
		m_MapDraw.DrawMidText("ũ��Ƽ��! �߰� ���ط� :" + to_string(m_iAddDamege), WIDTH, HEIGHT*0.48);
		m_iAddDamege = m_WeaponInfo.Damege * 1.5;
	}
	return m_WeaponInfo.Damege + m_iAddDamege;
}
int Wand::Attack()
{
	m_iAddDamege = 0;
	if (rand() % 100 <= 10)
	{
		m_MapDraw.DrawMidText("���̾! �߰� ���ط� :" + to_string(m_iAddDamege), WIDTH, HEIGHT*0.48);
		m_iAddDamege = m_WeaponInfo.Damege * 3;
	}
	return m_WeaponInfo.Damege + m_iAddDamege;
}

int Gun::Attack()
{
	m_iAddDamege = 0;
	if (rand() % 100 <=1)
	{
		m_MapDraw.DrawMidText("���! �߰� ���ط� :" + to_string(m_iAddDamege), WIDTH, HEIGHT*0.48);
		m_iAddDamege = m_WeaponInfo.Damege * 10000;
	}
	return m_WeaponInfo.Damege + m_iAddDamege;
}

int Sword::Attack()
{
	m_iAddDamege = 0;
	if (rand() % 100 <= 20)
	{
		m_MapDraw.DrawMidText("����! �߰� ���ط� :" + to_string(m_iAddDamege), WIDTH, HEIGHT*0.48);
		m_iAddDamege = m_WeaponInfo.Damege * 1.3;
	}
	return m_WeaponInfo.Damege + m_iAddDamege;
}

int Hammer::Attack()
{
	m_iAddDamege = 0;
	if (rand() % 100 <= 15)
	{
		m_MapDraw.DrawMidText("��ġ �����Ŵ�! �߰� ���ط� :" + to_string(m_iAddDamege), WIDTH, HEIGHT*0.48);
		m_iAddDamege = m_WeaponInfo.Damege * 2.5;
	}
	return m_WeaponInfo.Damege + m_iAddDamege;
}