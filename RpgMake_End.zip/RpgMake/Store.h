#pragma once
#include "Unit.h"

struct WEAPONCOUNT
{
	int DaggerCount = 0;
	int BowCount = 0;
	int GunCount = 0;
	int SwordCount = 0;
	int HammerCount = 0;
	int WandCount = 0;
};
enum WEAPON
{
	DAGGER = 1,
	GUN,
	SWORD,
	WAND,
	BOW,
	HAMMER
};

class Store
{
private:
	MapDraw m_DrawMap;
	Weapon* Weapons[256];
	int m_iWeaponCount;
	WEAPONCOUNT m_eWeaponcount;
	bool m_bAssign;
public:
	Store();
	~Store();
	void WeaponShop(Unit* Player);
	void WeaponShopTxt();
	void MemoryAssign(Unit* Player);
	void WeaponListPage(WEAPON Type, Unit* Player);
	int MaxWepaonCount(WEAPON Type);
	string WeaponGetName(WEAPON Type);
	void StoreListTxt(WEAPON Type, Unit* Player);
	void LoadWeaponList(int MaxWeaponCount);
	int ReturnWeaponCount(WEAPON Type);
};

