#include "Store.h"



Store::Store()
{
	m_iWeaponCount = 0;
	m_bAssign = false;
}


Store::~Store()
{
}


void Store::StoreListTxt(WEAPON Type,Unit* Player)
{
	m_DrawMap.Outline_Box();
	ORIGINAL
	m_DrawMap.DrawMidText("���� GOLD: " + to_string(Player->UnitInfo().m_iGOLD), WIDTH, HEIGHT*0.05);
	m_DrawMap.DrawMidText(WeaponGetName(Type) + " Shop", WIDTH, HEIGHT*0.1);
}

void Store::WeaponShopTxt()
{
	ORIGINAL
		m_DrawMap.DrawMidText("����SHOP����", WIDTH, HEIGHT*0.1);
	m_DrawMap.DrawMidText("Dagger", WIDTH + 1, HEIGHT*0.2);
	m_DrawMap.DrawMidText("Gun", WIDTH, HEIGHT*0.3);
	m_DrawMap.DrawMidText("Sword", WIDTH, HEIGHT*0.4);
	m_DrawMap.DrawMidText("Wand", WIDTH, HEIGHT*0.5);
	m_DrawMap.DrawMidText("Bow", WIDTH, HEIGHT*0.6);
	m_DrawMap.DrawMidText("Hammer", WIDTH, HEIGHT*0.7);
	m_DrawMap.DrawMidText("���ư���", WIDTH, HEIGHT*.8);
}

string Store::WeaponGetName(WEAPON Type)
{
	switch (Type)
	{
	case DAGGER:
		return "Dagger";
	case GUN:
		return "Gun";
	case SWORD:
		return "Sword";
	case WAND:
		return "Wand";
	case BOW:
		return "Bow";
	case HAMMER:
		return "Hammer";
	default:
		break;
	}
}

int Store::MaxWepaonCount(WEAPON Type)
{
	int Count = 0;
	for (int i = 0; i <= m_iWeaponCount; i++)
	{
		if (WeaponGetName(Type) == Weapons[i]->ReturnWeaponInfo().WeaponType)
		{
			Count++;
		}
	}
	return Count;
}

void Store::LoadWeaponList(int MaxWeaponCount)
{
	ifstream Load;
	string FileName = "WeaponList.txt";
	Load.open(FileName);
	for (int i = 0; i <= MaxWeaponCount; i++)
	{
		Weapons[i]->SaveWeaponInfo(Load);//���⼭ ����
	}
	Load.close();
}

void Store::WeaponShop(Unit* Player)
{
	bool m_bShop = true;
	while (m_bShop)
	{
		m_DrawMap.Outline_Box();
		WeaponShopTxt();
		int Select = m_DrawMap.MenuSelectCursor(7, 3, (WIDTH / 3) + 1, HEIGHT*0.2);
		if (Select == 7)
			m_bShop = false;
		else
		{
			MemoryAssign(Player);
			WeaponListPage((WEAPON)Select, Player);
		}
	}
}

void Store::MemoryAssign(Unit* Player)//
{
	ifstream Load;
	string ListName = "WeaponList.txt", WeaponName;
	string Weapontype;
	Weapon* StartNum;
	int Cost, Damege;

	if (m_bAssign == true);
	else
	{
		Load.open(ListName);
		while (!Load.eof())
		{
			Load >> Weapontype;
			Load >> WeaponName;
			Load >> Cost;
			Load >> Damege;
			if (Weapontype == "Dagger")
			{
				Weapons[m_iWeaponCount] = new Dagger(Weapontype, WeaponName, Damege, Cost);
				m_eWeaponcount.DaggerCount++;
			}
			else if (Weapontype == "Bow")
			{
				Weapons[m_iWeaponCount] = new Bow(Weapontype, WeaponName, Damege, Cost);
				m_eWeaponcount.BowCount++;
			}
			else if (Weapontype == "Sword")
			{
				Weapons[m_iWeaponCount] = new Sword(Weapontype, WeaponName, Damege, Cost);
				m_eWeaponcount.SwordCount++;
			}
			else if (Weapontype == "Wand")
			{
				Weapons[m_iWeaponCount] = new Wand(Weapontype, WeaponName, Damege, Cost);
				m_eWeaponcount.WandCount++;
			}
			else if (Weapontype == "Gun")
			{
				Weapons[m_iWeaponCount] = new Gun(Weapontype, WeaponName, Damege, Cost);
				m_eWeaponcount.GunCount++;
			}
			else if (Weapontype == "Hammer")
			{
				Weapons[m_iWeaponCount] = new Hammer(Weapontype, WeaponName, Damege, Cost);
				m_eWeaponcount.HammerCount++;
			}
			m_iWeaponCount++;
		}
		m_bAssign = true;
		m_iWeaponCount--;
		Load.close();
		//�� 0���� 29���� �Ҵ�. 29������ �ְ�ӿ���..?
		//�ϳ��� ���� ����,������������ �߰����µ� 0��°ĭ���� �Ǹ����� ���� ������ ����. 
		//-1�������ָ� ����,�������������� ���� 
	}

}

int Store::ReturnWeaponCount(WEAPON Type)
{
	switch (Type)
	{
	case DAGGER:
		return m_eWeaponcount.DaggerCount;
		break;
	case GUN:
		return m_eWeaponcount.GunCount;
		break;
	case SWORD:
		return m_eWeaponcount.SwordCount;
		break;
	case WAND:
		return m_eWeaponcount.WandCount;
		break;
	case BOW:
		return m_eWeaponcount.BowCount;
		break;
	case HAMMER:
		return m_eWeaponcount.HammerCount;
		break;
	default:
		break;
	}
}

void Store::WeaponListPage(WEAPON Type, Unit* Player)
{
	bool NextPage = false, InitMenu = true, Page = false, b_FirstAddress = true;
	int WeaponMenuCount = 0, startcount;
	int MaxCount,WepaonListCount;
	int SaveCount;
	float Add;//�Ÿ�����
	WepaonListCount = ReturnWeaponCount(Type);
	while (InitMenu)//ó�� �׷����°� 
	{
		if (WepaonListCount > 5)
			Page = true;
		else
			Page = false;
		Add = 0.17;
		startcount = 0;
		WeaponMenuCount = 0;
		LoadWeaponList(m_iWeaponCount);//������ �� �־��� 
		StoreListTxt(Type, Player);
		MaxCount = MaxWepaonCount(Type);//SaveCount =txt�ȿ� ����type ����
		for (startcount; startcount <= m_iWeaponCount; startcount++)//m_iWeaponCount= ������ �Ѱ���
		{
			if (WeaponGetName(Type) == Weapons[startcount]->ReturnWeaponInfo().WeaponType)
			{
				if (b_FirstAddress == true)
				{
					SaveCount =startcount;
				}
				b_FirstAddress = false;
				Weapons[startcount]->WeaponListTxt(WIDTH, HEIGHT*Add);
				Add += 0.1;
				WeaponMenuCount++;//Ÿ���� ������ ����

				if (WeaponMenuCount % 5 == 0)
				{
					startcount = startcount + 1;
					break;
				}
			}
		}
		m_DrawMap.DrawMidText("���� ������", WIDTH, HEIGHT*(Add += 0.05));
		m_DrawMap.DrawMidText("���� ������", WIDTH, HEIGHT*(Add += 0.1));
		m_DrawMap.DrawMidText("������", WIDTH, HEIGHT*(Add += 0.1));
		int Select = m_DrawMap.MenuSelectCursor(WeaponMenuCount + 3, 3.5, (WIDTH / 3) - 4.5, HEIGHT*0.2);

		if (Select > 0 && Select < WeaponMenuCount + 1)
		{
			Player->BuyItem(Weapons[SaveCount+(Select-1)], Player);
		}
		if (Select == WeaponMenuCount + 2 && Page==true)//�������� ���� 
			//���� ������ 5���̻��̶� �����ٰ��ְ� Page�� ó�������ϴ°�
		{
			NextPage = true;
			WepaonListCount -= 5;
		}

		if (Select == WeaponMenuCount + 3)//������ �����鳡����
		{
			InitMenu = false;
		}

		while (NextPage)//���� ������ �Ѿ���� ���� 1���� ������ �Ѿ��	�ƴϸ� �׳� ����
		{
			Add = 0.17;
			WeaponMenuCount = 0;
			m_DrawMap.Outline_Box();
			StoreListTxt(Type, Player);
			if (WepaonListCount > 5)
				Page = true;
			else
				Page = false;
			for (int i = startcount; i < m_iWeaponCount; i++)
			{
				if (WeaponGetName(Type) == Weapons[i]->ReturnWeaponInfo().WeaponType)
				{
					Weapons[i]->WeaponListTxt(WIDTH, HEIGHT*Add);
					Add += 0.1;
					WeaponMenuCount++;
					if (WeaponMenuCount % 5 == 0)
					{
						startcount = i + 1;
						break;
					}
				}
			}
			m_DrawMap.DrawMidText("���� ������", WIDTH, HEIGHT*(Add += 0.05));
			m_DrawMap.DrawMidText("���� ������", WIDTH, HEIGHT*(Add += 0.1));
			m_DrawMap.DrawMidText("������", WIDTH, HEIGHT*(Add += 0.1));
			int Select = m_DrawMap.MenuSelectCursor((MaxCount - 5) + 3, 3.5, (WIDTH / 3) - 4.5, HEIGHT*0.2);
			if (Select == WeaponMenuCount + 1)
			{
				InitMenu = true;
				NextPage = false;
				WepaonListCount += 5;
			}
			if (Select == WeaponMenuCount + 2 && Page==true)
			{
				InitMenu = false;
				NextPage = true;
			}
			if (Select == WeaponMenuCount + 3)
			{
				InitMenu = false;
				NextPage = false;
			}
		}
	}
}
