#pragma once
#include "Weapon.h"
enum UnitTYPE
{
	PLAYER,
	MONSTER
};

struct Unit_Info
{
	string m_strName;
	int m_iPower;
	int m_CurHealth;
	int m_iHealth;
	int m_iLevel;
	int m_iCurEXP;
	int m_iGetEXP;
	int m_iGOLD;
	int m_iMAXEXP;
	bool m_bWeapon;
	Weapon* WeaponType;
	string m_strWeaponType;
	string m_strWeaponName;
	int m_iWeaponDamge;
	int m_iWeaponGold;
};

class Unit
{
private:
	MapDraw m_DrawMap;
	ofstream Save;
	ifstream Load;
	Weapon* weapons;
protected:
	Unit_Info Info;
public:
	Unit();
	~Unit();
	void Init(ifstream& Load, UnitTYPE Type);
	void ShowInfo(int x, int y);
	void InfoSave(int num, ofstream& Save, Unit* Player,bool PlayerCheck);
	void InfoLoad(ifstream& Load,Unit* Player, bool PlayerCheck);
	bool Attack(Unit* WinUnit,Unit* LoseUnit, Unit* PlayerName);
	void HealReset();
	void LevelUp();
	void BuyItem(Weapon* weapon,Unit* Player);
	inline Unit_Info UnitInfo()
	{
		return Info;
	}
	inline int ReturnGold()
	{
		return Info.m_iGOLD;
	}
	inline int ReturnPlayerLife()
	{
		return Info.m_CurHealth;
	}

};

