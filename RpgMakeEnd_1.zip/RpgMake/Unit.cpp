#include "Unit.h"



Unit::Unit()
{
	Info.m_bWeapon = false;
}


Unit::~Unit()
{
}

void Unit::Init(ifstream& Load, UnitTYPE Type)
{
	if (Type == PLAYER)
	{
		m_DrawMap.DrawMidText("Player �̸� �Է� : ", WIDTH, HEIGHT*0.5);
		cin >> Info.m_strName;
	}
	else
	{
		Load >> Info.m_strName;
	}
	Load >> Info.m_iPower;
	Load >> Info.m_iHealth;
	Load >> Info.m_iMAXEXP;
	Load >> Info.m_iGetEXP;
	Load >> Info.m_iLevel;
	Load >> Info.m_iGOLD;
	Info.m_CurHealth = Info.m_iHealth;
	Info.m_iCurEXP = 0;
}

void Unit::InfoLoad(ifstream& Load,Unit* Player,bool PlayerCheck)
{
	Load >> Info.m_strName;
	Load >> Info.m_iPower;
	Load >> Info.m_iHealth;
	Load >> Info.m_iMAXEXP;
	Load >> Info.m_iGetEXP;
	Load >> Info.m_iLevel;
	Load >> Info.m_iGOLD;
	Load >> Info.m_iCurEXP;
	Load >> Info.m_CurHealth;
	if (PlayerCheck)
	{
		Load >> Info.m_bWeapon;
		Load >> Info.m_strWeaponType;
		Load >> Info.m_strWeaponName;
		Load >>	Info.m_iWeaponDamge;
		Load >> Info.m_iWeaponGold;
		if (Info.m_bWeapon == true)
		{
			if (Info.m_strWeaponType == "Dagger")
			{
				weapons = new Dagger(Info.m_strWeaponType, Info.m_strWeaponName, Info.m_iWeaponDamge, Info.m_iWeaponGold);
			}
			else if (Info.m_strWeaponType == "Bow")
			{
				weapons = new Bow(Info.m_strWeaponType, Info.m_strWeaponName, Info.m_iWeaponDamge, Info.m_iWeaponGold);
			}
			else if (Info.m_strWeaponType == "Wand")
			{
				weapons = new Wand(Info.m_strWeaponType, Info.m_strWeaponName, Info.m_iWeaponDamge, Info.m_iWeaponGold);
			}
			else if (Info.m_strWeaponType == "Sword")
			{
				weapons = new Sword(Info.m_strWeaponType, Info.m_strWeaponName, Info.m_iWeaponDamge, Info.m_iWeaponGold);
			}
			else if (Info.m_strWeaponType == "Gun")
			{
				weapons = new Gun(Info.m_strWeaponType, Info.m_strWeaponName, Info.m_iWeaponDamge, Info.m_iWeaponGold);
			}
			else if (Info.m_strWeaponType == "Hammer")
			{
				weapons = new Hammer(Info.m_strWeaponType, Info.m_strWeaponName, Info.m_iWeaponDamge, Info.m_iWeaponGold);
			}
			Info.WeaponType = weapons;
		
		}
	}
}

void Unit::InfoSave(int num,ofstream& Save,Unit* Player,bool PlayerCheck)
{
	Save << Info.m_strName<<" ";
	Save << Info.m_iPower<<" ";
	Save << Info.m_iHealth <<" ";
	Save << Info.m_iMAXEXP<<" ";
	Save << Info.m_iGetEXP << " ";
	Save << Info.m_iLevel << " ";
	Save << Info.m_iGOLD << " ";
	Save << Info.m_iCurEXP << " ";
	Save << Info.m_CurHealth<<" "<<endl;
	if (PlayerCheck)
	{
		Save << Info.m_bWeapon << " ";
		if (Info.m_bWeapon == true)
		{
			Save << Player->Info.m_strWeaponType<<" ";
			Save << Player->Info.m_strWeaponName<<" ";
			Save << Player->Info.m_iWeaponDamge<<" ";
			Save << Player->Info.m_iWeaponGold<<" ";
		}
	}
}

void Unit::ShowInfo(int x,int y)
{
	m_DrawMap.gotoxy(x,y);
	cout << "  ======" << Info.m_strName << "(" << Info.m_iLevel << "Lv)======" << endl;
	m_DrawMap.gotoxy(x, y+1);
	cout << "\t���ݷ� = " <<Info.m_iPower <<"\t������ = "<<Info.m_CurHealth<<"/"<<Info.m_iHealth << endl;
	m_DrawMap.gotoxy(x, y+2);
	cout << "\t����ġ :"<<Info.m_iCurEXP <<"/" <<Info.m_iMAXEXP <<"\t GETEXP :"<< Info.m_iGetEXP << endl;
	m_DrawMap.gotoxy(x ,y+3);
	cout << "\tGold :" << Info.m_iGOLD << endl;
	if (Info.m_bWeapon == true)
	{
		m_DrawMap.gotoxy(x/2, y + 4);
		cout << "����Ÿ��:" << Info.m_strWeaponType << "  �����̸� :" << Info.m_strWeaponName << " ���ݷ� : " << Info.m_iWeaponDamge;
	}
}

bool Unit::Attack(Unit* WinUnit,Unit* LoseUnit,Unit* PlayerName)//Unit
{
	int DefaultDamege=0,SkillDamege=0;
	DefaultDamege = WinUnit->Info.m_iPower;
	if (WinUnit->Info.m_bWeapon)
	{
		SkillDamege = WinUnit->Info.WeaponType->Attack();
	}
	LoseUnit->Info.m_CurHealth -= DefaultDamege+SkillDamege;

	if (LoseUnit->Info.m_CurHealth <= 0)
	{
		m_DrawMap.Outline_Box();
		LoseUnit->Info.m_CurHealth = 0;
		WinUnit->Info.m_iCurEXP+=LoseUnit->Info.m_iGetEXP;
		
		m_DrawMap.DrawMidText(WinUnit->Info.m_strName + "�¸�", WIDTH, HEIGHT*0.3);
		m_DrawMap.DrawMidText(WinUnit->Info.m_strName + " �� ����ġ "+to_string(LoseUnit->Info.m_iGetEXP)+
			" �� ������ϴ�.", WIDTH, HEIGHT*0.5);
		getch();
		if (WinUnit->Info.m_iCurEXP >= WinUnit->Info.m_iMAXEXP)
		{
			WinUnit->LevelUp();
		}
		LoseUnit->HealReset();
		return false;
	}
	return true;
}

void Unit::HealReset()
{
	Info.m_CurHealth = Info.m_iHealth;
}
void Unit::BuyItem(Weapon* weapon, Unit* Player)
{
	if (Info.m_iGOLD >= weapon->ReturnWeaponInfo().Cost)
	{
		Player->Info.m_iGOLD -= weapon->ReturnWeaponInfo().Cost;
		Player->Info.m_strWeaponType = weapon->ReturnWeaponInfo().WeaponType;
		Player->Info.m_strWeaponName = weapon->ReturnWeaponInfo().WeaponName;
		Player->Info.m_iWeaponDamge = weapon->ReturnWeaponInfo().Damege;
		Player->Info.m_iWeaponGold = weapon->ReturnWeaponInfo().Cost;
		Player->Info.m_bWeapon = true;
		if (weapon->ReturnWeaponInfo().WeaponType == "Dagger")
		{
			weapon = new Dagger(Player->Info.m_strWeaponType,Player->Info.m_strWeaponName,Player->Info.m_iWeaponDamge,Player->Info.m_iGOLD);
		}
		else if (weapon->ReturnWeaponInfo().WeaponType == "Bow")
		{
			weapon = new Bow(Player->Info.m_strWeaponType, Player->Info.m_strWeaponName, Player->Info.m_iWeaponDamge, Player->Info.m_iGOLD);
		}
		else if (weapon->ReturnWeaponInfo().WeaponType == "Gun")
		{
			weapon = new Gun(Player->Info.m_strWeaponType, Player->Info.m_strWeaponName, Player->Info.m_iWeaponDamge, Player->Info.m_iGOLD);
		}
		else if (weapon->ReturnWeaponInfo().WeaponType == "Sword")
		{
			weapon = new Sword(Player->Info.m_strWeaponType, Player->Info.m_strWeaponName, Player->Info.m_iWeaponDamge, Player->Info.m_iGOLD);
		}
		else if (weapon->ReturnWeaponInfo().WeaponType == "Wand")
		{
			weapon = new Wand(Player->Info.m_strWeaponType, Player->Info.m_strWeaponName, Player->Info.m_iWeaponDamge, Player->Info.m_iGOLD);
		}
		else if (weapon->ReturnWeaponInfo().WeaponType == "Hammer")
		{
			weapon = new Hammer(Player->Info.m_strWeaponType, Player->Info.m_strWeaponName, Player->Info.m_iWeaponDamge, Player->Info.m_iGOLD);
		}
		Player->Info.WeaponType = weapon;
	}
}

void Unit::LevelUp()
{
	int PowerUpgrade,HealthUpgrade,EXPUpgrade;
	PowerUpgrade = ceil(Info.m_iPower*0.2);
	HealthUpgrade = ceil(Info.m_CurHealth*0.3);
	EXPUpgrade = ceil(Info.m_iMAXEXP*0.2);
	Info.m_iPower += PowerUpgrade;
	Info.m_iHealth += HealthUpgrade;
	Info.m_iMAXEXP += EXPUpgrade;
	Info.m_iCurEXP = 0;
	Info.m_iLevel++;
	m_DrawMap.Outline_Box();
	m_DrawMap.DrawMidText(Info.m_strName + " Level Up!", WIDTH, HEIGHT*0.3);
	m_DrawMap.DrawMidText("���ݷ� " + to_string(PowerUpgrade) + "����", WIDTH, HEIGHT*0.5);
	m_DrawMap.DrawMidText("������ " + to_string(HealthUpgrade) + "����", WIDTH, HEIGHT*0.7);
	HealReset();
	getch();
}