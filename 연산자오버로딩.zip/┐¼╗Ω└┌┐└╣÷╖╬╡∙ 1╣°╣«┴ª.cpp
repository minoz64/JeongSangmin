#include <iostream>

using namespace std;
class Point
{
private:
	int m_px,m_py;
public:
	Point() {};
	Point(int a, int b)
	{
		m_px = a, m_py = b;
	};
	void print()
	{
		cout << "x = " << m_px << " y = " << m_py<<endl;
	};
	friend Point operator / (Point num1,Point num2);
};

Point operator/(Point num1, Point num2)
{
	Point num3;
	cout << "��ü / ��ü"<<endl;

	if (num1.m_px > num2.m_px)
		num3.m_px = num1.m_px / num2.m_px;
	else
		num3.m_px = num2.m_px / num1.m_px;

	if (num1.m_py > num2.m_py)
		num3.m_py = num1.m_py / num2.m_py;
	else
		num3.m_py = num2.m_py / num1.m_py;

	return num3;
}


void main()
{
	Point p1(10, 20), p2(5, 40);
	p1.print();
	p2.print();
	p1 = p1 / p2;
	p1.print();
}