#include <iostream>
#include <Windows.h>
using namespace std;

class Time {
private:
	int m_iHour;
	int m_iMin;
public:
	void ShowTime();
	Time operator + (Time time);
	Time(){};
	Time(int Hour, int Min) { m_iHour = Hour,m_iMin = Min;};
	~Time(){};
};
void Time::ShowTime()
{
	cout << "�� ���� �ð� : " << m_iHour << " : " << m_iMin << endl;
	
}
Time Time::operator+(Time time)
{
	Time Add;
	Add.m_iHour= this->m_iHour+time.m_iHour;
	Add.m_iMin = this->m_iMin+time.m_iMin;
	if (Add.m_iMin >= 60)
	{
		Add.m_iMin -= 60;
		Add.m_iHour++;
	}
	return Add;
}
void main()
{
	Time t(0,0);
	int H, M,select,Day=1;
	while (1)
	{
		system("cls");
		t.ShowTime();
		cout << "=====���� �ð� ���� ���α׷�<"<< Day << "Day>=====" << endl;
		cout << "\t\t1.�ð����" << endl;
		cout << "\t\t2.����" << endl;
		cout << "�Է� :";
		cin >> select;
		switch (select)
		{
			case 1:
			{
				cout << "�ð� :";
				cin >> H;
				cout << "�� : ";
				cin >> M;
				Time t1(H, M);
				t =t+t1;
				Day++;
			}
			break;
			case 2:
			{
				system("cls");
				t.ShowTime();
				return;
			}
		}
	}
}